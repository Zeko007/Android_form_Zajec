package hr.anu_patricia_zajec;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class secondActivity extends AppCompatActivity {

private TextView txt;

public static final String tag = "secondActivity";

@Override

    protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_second);

    txt = findViewById(R.id.textView);
}

}
